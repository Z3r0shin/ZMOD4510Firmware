// This is an include wrapper for arduino, allowing usage of
// the include file structure of the EVK and Raspberry examples

#include "sensors/zmod4xxx.h"
